#include <iostream>
#include "User.h"
#include <string>
#include <vector>
#include <fstream>
using namespace std;

User::User(const std::string& full_name, const std::string& email,
    const vector<std::string>& watch_history)
{
    //make vector for movie id's
    m_name = full_name; m_email = email;
    for (int i = 0; i < watch_history.size(); i++) {
        m_watchHistory.push_back(watch_history[i]);
    }
}

string User::get_full_name() const
{
    return m_name;  
}

string User::get_email() const
{
    return m_email;  
}

vector<string> User::get_watch_history() const
{
    return m_watchHistory;  
}
