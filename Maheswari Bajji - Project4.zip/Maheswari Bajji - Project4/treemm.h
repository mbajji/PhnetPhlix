#ifndef TREEMULTIMAP_INCLUDED
#define TREEMULTIMAP_INCLUDED
#include <vector>
template <typename KeyType, typename ValueType>
class TreeMultimap
{
private:
    struct Node {
        KeyType m_key;
        std::vector <ValueType> m_value;
        Node* smallerSubTree, * biggerSubTree;

        //function to create a new Node
        Node(KeyType key, ValueType value) {
            m_key = key;
            m_value.push_back(value);
            smallerSubTree = nullptr;
            biggerSubTree = nullptr; 
        }
        std::vector <ValueType>& getVector() {
            return m_value;
        }

    };



    Node* m_root;
    //recursive function to delete all Nodes one at a time
    void deleteNodes(Node* p) {
        if (p == nullptr)
            return;
        deleteNodes(p->biggerSubTree);
        deleteNodes(p->smallerSubTree);
        delete p;
        p = nullptr; 
    }
public:
    class Iterator
    {
    public:
        Iterator()
        {
            currentLoc = -1; 
            myValues = nullptr; 
        }
        Iterator(Node* value):myValues(value), currentLoc(0)
        { }
       
        ValueType& get_value() const
        {
           return myValues->m_value[currentLoc];
        }

        bool is_valid() const
        {
            //check if myValues is not nullptr and if currentLoc is a valid index
            return (myValues!=nullptr && currentLoc >= 0 && (currentLoc < myValues->m_value.size()));
        }

        void advance()
        {
            currentLoc++; 
        }

    private:
        Node* myValues;
        int currentLoc; 
    };

    TreeMultimap()
    {
        m_root = nullptr;
    }

    ~TreeMultimap()
    {
        //call recursive function to delete all nodes
        deleteNodes(m_root);
        m_root = nullptr; 
    }

    void insert(const KeyType& key, const ValueType& value)
    {
        //if it is the root node, just insert to root
        if (m_root == nullptr) {
            
            m_root = new Node(key,value);
            m_root->smallerSubTree = nullptr; 
            m_root->biggerSubTree = nullptr;
            //return so that the bottom is not done
            return; 
        }
       
        //if it is not the root node, insert in corect spot
        Node* currentNode = m_root;
        Node* prevNode = m_root;
        //loop until the end is reached so that you can insert in correct spot 
        while (currentNode != nullptr) 
        {
            //if the value already exists add to vector
            if (key == currentNode->m_key) {
                currentNode->m_value.push_back(value); return;
            }
            //if the inseting value is Bigger go to the right
            else if (key > (currentNode->m_key)) {
                prevNode = currentNode;
                currentNode = currentNode->biggerSubTree;
            }
            //the key is smaller so go to the Left/smaller subtree
            else
            {
                

                prevNode = currentNode;
                currentNode = currentNode->smallerSubTree;
            }
        }
        // You are at the bottom of the correct place the value has to be inserted
        currentNode = new Node(key, value); 
        //conneting the prev values to the new value based on value 
        if (currentNode->m_key > prevNode->m_key) {
            prevNode->biggerSubTree = currentNode; 
        }
        else
        {
            prevNode->smallerSubTree = currentNode; 
        }
        return; 
    }

    Iterator find(const KeyType& key) const
    {
        //loop through the BST until a match is found
        Node* currentNode = m_root;
        while (currentNode != nullptr)
        {
            if ((currentNode->m_key) == key)
            {
                //return an Iterator to that value
                return Iterator(currentNode);
            }
            else
            {
                //move in the right direction based on "alphabetical" order
                if (key > (currentNode->m_key))
                {
                    currentNode = currentNode->biggerSubTree; 
                }
                else
                    currentNode = currentNode->smallerSubTree;
            }
        }
        //if no match return an invalid Iterator 
        return Iterator();
    }
};

#endif // TREEMULTIMAP_INCLUDED

