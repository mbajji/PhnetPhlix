#ifndef MOVIE_INCLUDED
#define MOVIE_INCLUDED
#include <iostream>
#include <string>
#include <vector>
using namespace std; 
class Movie
{
public:
    Movie(const std::string& id, const std::string& title,
        const std::string& release_year,
        const std::vector<std::string>& directors,
        const std::vector<std::string>& actors,
        const std::vector<std::string>& genres, float rating);
    ~Movie() {}
    std::string get_id() const;
    std::string get_title() const;
    std::string get_release_year() const;
    float get_rating() const;
    std::vector<std::string> get_directors() const;
    std::vector<std::string> get_actors() const;
    std::vector<std::string> get_genres() const;

private:
    string m_id; 
    string m_title; 
    string m_releaseYear; 
    vector<string> m_directors; 
    vector<string> m_actors; 
    vector<string> m_genres;
    float m_rating; 
};

#endif // MOVIE_INCLUDED

