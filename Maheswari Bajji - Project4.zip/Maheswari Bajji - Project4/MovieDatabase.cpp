#include "MovieDatabase.h"
#include "Movie.h"
#include <string>
#include <vector>
#include <fstream>
#include <cctype>

using namespace std;

MovieDatabase::MovieDatabase(): currentIndex(0)
{}

bool MovieDatabase::load(const string& filename)
{
    //if it was already loaded return false 
    if (l) return false;
    std::ifstream myfile;
    //open file 
    myfile.open(filename);
    string id,name,year,s,rating; 
    if (myfile.is_open())
    {
        //read file until directors line is reached
        while (myfile.good()) {
            getline(myfile, id); 
            getline(myfile, name);
            getline(myfile, year);
            //get directors
            getline(myfile, s);
            vector<string> myDirectors = getValues(s); 
           
            //get actors
            getline(myfile, s);
            vector<string> myActors = getValues(s);
            
            //get genres
            getline(myfile, s);
            vector<string> myGenres = getValues(s);
            //get rating 
            getline(myfile, rating);
            loadTrees(id, name, year, myDirectors, myActors, myGenres, stof(rating)); 
            getline(myfile, s); 
        }
    }
    l = true;
    return true; 
}

Movie* MovieDatabase::get_movie_from_id(const string& id) const
{
    //chaneg all to lowercase 
    string idC = changeCase(id);

    auto it = id2movieIndex.find(idC);
    if (!it.is_valid()) return nullptr; 
    return movies[it.get_value()]; 
}

vector<Movie*> MovieDatabase::get_movies_with_director(const string& director) const
{
    vector<Movie*> m; 
    string d = changeCase(director);

    auto it = director2movieIndex.find(d); 
    //make vector using the iterator class
    while (it.is_valid()) {
        m.push_back(movies[it.get_value()]); 
        it.advance(); 
    }
    return m;  
}

vector<Movie*> MovieDatabase::get_movies_with_actor(const string& actor) const
{
    vector<Movie*> m;
    string a = changeCase(actor);
    //get a iterator and get vector using iterator
    auto it = actor2movieIndex.find(a);
    while (it.is_valid()) {
        m.push_back(movies[it.get_value()]);
        it.advance();
    }
    return m; 
}

vector<Movie*> MovieDatabase::get_movies_with_genre(const string& genre) const
{
    vector<Movie*> m;
    string g = changeCase(genre); 
    //get genres
    auto it = genre2movieIndex.find(g);
    while (it.is_valid()) {
        m.push_back(movies[it.get_value()]);
        it.advance();
    }
    return m;  
}

vector<string> MovieDatabase::getValues(string s) {
    vector<string> myValues; 
    if (s == "") return myValues; 

    //look for a comma
    size_t pos = s.find(',');
    //loop until end of string and split commas using a built in function for strings
    while (pos != s.npos)
    {
        string temp = s.substr(0, pos);
        myValues.push_back(temp);
        s = s.substr(pos + 1);
        pos = s.find(',');
    }
    //last time need to do again 
    myValues.push_back(s);
    return myValues;
}

void MovieDatabase::loadTrees(const std::string& id, const std::string& title,
    const std::string& release_year,
    const std::vector<std::string>& directors,
    const std::vector<std::string>& actors,
    const std::vector<std::string>& genres, float rating) {
    Movie* m = new Movie(id, title, release_year, directors, actors, genres, rating);
    //load dir
    string idC = changeCase(id);
    id2movieIndex.insert(idC, currentIndex);  
    for (int i = 0; i < directors.size(); i++) { 
        string d = changeCase(directors[i]); 
        director2movieIndex.insert(d, currentIndex); 
    }
    //load actor
    for (int i = 0; i < actors.size(); i++) {
        string a = changeCase(actors[i]); 
        actor2movieIndex.insert(a, currentIndex);
    }
    //load genre
    for (int i = 0; i < genres.size(); i++) {
        string g = changeCase(genres[i]); 
        genre2movieIndex.insert(g, currentIndex);
    }
    movies.push_back(m); 
    currentIndex++; 
}
