#ifndef MOVIEDATABASE_INCLUDED
#define MOVIEDATABASE_INCLUDED

#include <string>
#include <vector>
#include "Movie.h"
#include "treemm.h"


class MovieDatabase
{
public:
    MovieDatabase();
    ~MovieDatabase() {
        for (int i = 0; i < movies.size(); i++) {  
            delete movies[i]; 
            movies[i] = nullptr;
        } 
    };
    bool load(const std::string& filename);
    Movie* get_movie_from_id(const std::string& id) const;
    std::vector<Movie*> get_movies_with_director(const std::string& director) const;
    std::vector<Movie*> get_movies_with_actor(const std::string& actor) const;
    std::vector<Movie*> get_movies_with_genre(const std::string& genre) const;

private:
    TreeMultimap<string, int> id2movieIndex; 
    TreeMultimap<string, int> director2movieIndex; 
    TreeMultimap<string, int> actor2movieIndex;
    TreeMultimap<string, int> genre2movieIndex;
    vector<Movie*> movies; 
    int currentIndex = 0;
    bool l = false; 
    vector<string> getValues(string s);
    void loadTrees(const std::string& id, const std::string& title,
        const std::string& release_year,
        const std::vector<std::string>& directors,
        const std::vector<std::string>& actors,
        const std::vector<std::string>& genres, float rating);
    string changeCase(string s) const{
        string str = s;
        for (int i = 0; i < str.size(); i++) {
            str[i] = tolower(str[i]);
        }
        return str; 
    }
};

#endif // MOVIEDATABASE_INCLUDED
