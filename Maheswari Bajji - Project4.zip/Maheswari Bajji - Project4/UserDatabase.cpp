#include "User.h"
#include "UserDatabase.h"

#include <fstream>
#include "treemm.h"
#include <string>
#include <vector>
using namespace std;

UserDatabase::UserDatabase(){ 
    usrPtr.clear(); 
}

bool UserDatabase::load(const string& filename)
{
    //if was already loaded return false
    if (usrPtr.size() != 0) { return false;  }

    std::ifstream myfile; 
    vector<string> movies; 
    myfile.open(filename); 
    string myline, name, email, count;
    if (myfile.is_open()) 
    {
        while (myfile.good()) {
            getline(myfile, name);
            getline(myfile, email);
            getline(myfile, count);
            
            //loop thourgh all N movies and make a vector
            for (int i = 0; i < stoi(count); i++) {
                getline(myfile, myline , '\n');
                movies.push_back(myline);
            }
            //create a new user using the given values and append to user vector 
            User* u = new User(name, email, movies); 

            //inserting to binary tree 
           email2User.insert(email,u);
           usrPtr.push_back(u); 
           
           //cleat the movies vector so that we dont have extra movies 
           movies.clear(); 
           getline(myfile, myline);
        }
    }
    return true;  
}

User* UserDatabase::get_user_from_email(const string& email) const
{
    //get an iterator to that email and return the user 
    TreeMultimap<std::string, User*>::Iterator it = email2User.find(email);
   if (!it.is_valid()) return nullptr;  
    return (it.get_value()); 
}


