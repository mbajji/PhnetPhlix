#include <iostream>

#include <vector>
#include <map>
#include "Recommender.h"
#include "treemm.h"

#include "UserDatabase.h"
#include "MovieDatabase.h"

#include <string>
#include <algorithm>
using namespace std;

Recommender::Recommender(const UserDatabase& user_database,
    const MovieDatabase& movie_database) :udb(user_database), mdb(movie_database)
{}
std::vector<MovieAndRank> Recommender::recommend_movies(
    const std::string& user_email, int movie_count) const
{
    //if invalid count return empty vector 
    if (movie_count < 0) return vector<MovieAndRank>();
    //create a map 
    map<string, MovieAndRank> compatabilityScore;
    //get user from the email
    User* m_user = udb.get_user_from_email(user_email);
    //if usre doesnt exist return empty vector
    if (m_user == nullptr) return vector<MovieAndRank>();
    //get the watch history
    vector<string> watch_history = m_user->get_watch_history();
    vector<Movie*> moviesFromDirector, moviesFromActor, moviesFromGenre;

    for (int i = 0; i < watch_history.size(); i++) {
        string currentMovieID = watch_history[i];
        Movie* currentMovie = mdb.get_movie_from_id(currentMovieID);
        //if current movie is not in database continue with next movie in vector
        if (currentMovie == nullptr) continue;

        //get the current movies directors,actors and genres 
        vector<string> directors = currentMovie->get_directors();
        vector<string> actors = currentMovie->get_actors();
        vector<string> genres = currentMovie->get_genres();

        //a vector with all directors, actoes and genres 
        vector<Movie*> allMovieswithDirector, allMovieswithActor, allMovieswithGenre;

        //directors
        //for each director get all movies they directed
        for (int j = 0; j < directors.size(); j++) {
            //get all movies director i directed 
            allMovieswithDirector = mdb.get_movies_with_director(directors[j]);

            //for each movie they directed get a compatability score 
            for (int k = 0; k < allMovieswithDirector.size(); k++) {
                //get j's movie the director created directors
                Movie* currentSearchingMovie = allMovieswithDirector[k];
                auto itr = compatabilityScore.find(currentSearchingMovie->get_id());
                if (itr == compatabilityScore.end()) {
                    //add 20 points if its a new movie
                    compatabilityScore.insert({ currentSearchingMovie->get_id(), MovieAndRank(currentSearchingMovie->get_id(),20) });
                }
                else {
                    
                    (itr->second.compatibility_score) += 20 ;
                }
            }
        }

        //actors loading and giving points 
        for (int j = 0; j < actors.size(); j++) {
            //get all movies director i directed 

            allMovieswithActor = mdb.get_movies_with_actor(actors[j]);

            //for each movie they directed get a compatability score 
            for (int k = 0; k < allMovieswithActor.size(); k++)
            {
                //get j's movie the director created directors
                Movie* currentSearchingMovie = allMovieswithActor[k];
                auto itr = compatabilityScore.find(currentSearchingMovie->get_id());
                if (itr == compatabilityScore.end()) {
                    //add 30 points if the movie is new
                    compatabilityScore.insert({ currentSearchingMovie->get_id(), MovieAndRank(currentSearchingMovie->get_id(),30) });
                }
                else {
                  
                    (itr->second.compatibility_score) += 30;
                }
            }
        }

        //genres loading 
        for (int j = 0; j < genres.size(); j++) {
            //get all movies with genre

            allMovieswithGenre = mdb.get_movies_with_genre(genres[j]);

            //for each movie get a compatability score 
            for (int k = 0; k < allMovieswithGenre.size(); k++)
            {
                Movie* currentSearchingMovie = allMovieswithGenre[k];
                auto itr = compatabilityScore.find(currentSearchingMovie->get_id());
                if (itr == compatabilityScore.end()) {
                    //if movie doesnt exist add to map
                    compatabilityScore.insert({ currentSearchingMovie->get_id(), MovieAndRank(currentSearchingMovie->get_id(),1) });
                }
                else {
                    //else add 1 point
                    (itr->second.compatibility_score) += 1;
                    
                }
            }
        }
    }

    //create my vector of recs
    vector<MovieAndRank> myRecs;
    //make sure you have the necessary amount by having a unique score count 
    int countOfUniqueScores = 0;
    //until the map ends and we do not have n unique recs

    while (!compatabilityScore.empty() && countOfUniqueScores <= movie_count)
    {
        //find max score in map 
        std::map<string, MovieAndRank>::iterator best
            = std::max_element(compatabilityScore.begin(), compatabilityScore.end(), [](const std::pair<string, MovieAndRank>& a, const std::pair<string, MovieAndRank>& b)->bool { return a.second.compatibility_score < b.second.compatibility_score; });
        //get iterator to that movie with max score 
        auto iForWatchHistory = std::find(watch_history.begin(), watch_history.end(), best->first);
        if (iForWatchHistory == watch_history.end())
        {
            //check where to insert
            //check if there is same compatability score u
            bool alreadyPushed = false;
            //bests's values 
            Movie* currInsertion = mdb.get_movie_from_id(best->second.movie_id); 
            float ratingB = currInsertion->get_rating();
            string titleB = currInsertion->get_title();
            int  cScoreB = (best->second.compatibility_score);

            for (int j = 0; j < myRecs.size(); j++)
            {
                //loop through vector and seeing if score exists 
                int cScoreA = (myRecs[j].compatibility_score);
                if (cScoreA != cScoreB) {
                    continue;
                }
                else
                {
                    //check ranking
                    float ratingA = mdb.get_movie_from_id(myRecs[j].movie_id)->get_rating(); 
                        
                    if (ratingA == ratingB) {
                        //check alphabet
                        string titleA = mdb.get_movie_from_id(myRecs[j].movie_id)->get_title(); 
                        if (titleA > titleB)
                        {
                            //insert to correct place 
                            myRecs.insert(myRecs.begin() + j, best->second); alreadyPushed = true;
                            break;
                        }
                        else continue;
                    }
                    //check rating 
                    else if (ratingA < ratingB) {
                        myRecs.insert(myRecs.begin() + j, best->second); alreadyPushed = true; break;
                    }
                    else {
                        continue;
                    }
                }
            }
            //push to end 
            if (!alreadyPushed) {
                countOfUniqueScores++;
                myRecs.push_back(best->second);
            }
        }
        //erase the current max value
        compatabilityScore.erase(best->first);
    }
   
    //return the first movie_count items 
    vector<MovieAndRank> recomenndationForUser;
    for (int i = 0; i < movie_count && i < myRecs.size(); i++)
    {
        recomenndationForUser.push_back(myRecs[i]);
    }
    return recomenndationForUser;
}
