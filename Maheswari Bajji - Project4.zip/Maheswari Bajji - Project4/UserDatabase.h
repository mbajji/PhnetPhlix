#ifndef USERDATABASE_INCLUDED
#define USERDATABASE_INCLUDED

#include <iostream>
#include <string>
#include <vector>
#include "User.h"
#include "treemm.h"
//class User;

class UserDatabase
{
public: 
    UserDatabase();
    ~UserDatabase() {
        for (int i = 0; i < usrPtr.size(); i++) {
            delete usrPtr[i]; 
            usrPtr[i] = nullptr; 
        }
        usrPtr.clear(); 
    };
    bool load(const std::string& filename);
    User* get_user_from_email(const std::string& email) const;
    
private:
   TreeMultimap<std::string,User*> email2User; 
   vector<User*> usrPtr; 
};

#endif // USERDATABASE_INCLUDED

